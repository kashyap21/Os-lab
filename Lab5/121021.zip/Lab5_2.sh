if [ "$1" == `echo $1 | rev` ]
then echo "pal"
else echo "not pal"
fi
