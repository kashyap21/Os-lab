yes $1 | head -n $2
